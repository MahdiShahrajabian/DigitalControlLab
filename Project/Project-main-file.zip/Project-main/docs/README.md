# How to generate docs:

Use this to install markdown tooling:

``pip install mkdocs-material``

Use this to serve the web page locally:

``mkdocs serve --config-file docs/mkdocs.yml``

Using IntelliJ, you can add ``bin/serve.sh`` as a run config.

# How to change the menu

The menu is listed in mkdocs.yml.
